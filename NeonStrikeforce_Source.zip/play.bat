@echo off
title Neon Strikeforce - Installer & Launcher
echo ==========================================
echo Compiling Neon Strikeforce .exe locally...
echo ==========================================
g++ game.cpp -o neon_strikeforce.exe -std=c++17 -O2 -lopengl32 -lgdi32 -mwindows -static
if %errorlevel% neq 0 (
    echo [ERROR] g++ compiler not found! Please install MinGW or use winget install BrechtSanders.WinLibs.POSIX.UCRT
    pause
    exit /b
)
echo Success! Launching game...
start neon_strikeforce.exe
